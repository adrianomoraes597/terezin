import flet as ft

def main(page:ft.Page):

    page.add(

        ft.ElevatedButton("Socorro")
        
    )

ft.app(target = main)